 import 'package:flutter/src/material/app_bar.dart';

import '../Dispensing/cart.dart';

class WebviewScaffold extends CartScreen{
  WebviewScaffold({required super.user, required String url, required AppBar appBar});
  
 }