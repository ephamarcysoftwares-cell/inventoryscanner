import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animate_do/animate_do.dart';

import '../Dispensing/cart.dart';

// --------------------------------------------------------------------------
// 1 STOCK ONLINE STORE - ARUSHA TERMINAL V4.0 (900+ LINES)
// SYSTEM: ARUSHA - ONLINE - STOCK - 1 - JOHANES - TZ
// --------------------------------------------------------------------------

class UniversalTerminalPage extends StatefulWidget {
  final Map<String, dynamic> user;
  const UniversalTerminalPage({super.key, required this.user});

  @override
  State<UniversalTerminalPage> createState() => _UniversalTerminalPageState();
}

class _UniversalTerminalPageState extends State<UniversalTerminalPage> with TickerProviderStateMixin {
  // --- DATABASE CONNECTIVITY ---
  final SupabaseClient _supabase = Supabase.instance.client;

  // --- UI CONTROLLERS ---
  final TextEditingController _mainController = TextEditingController();
  final FocusNode _scannerFocus = FocusNode();
  final ScrollController _cartScrollController = ScrollController();

  // --- STATE PERSISTENCE ---
  bool _isLoading = false;
  bool _isDarkMode = false;
  bool _isOnline = true;
  List<Map<String, dynamic>> _cartItems = [];
  String _lastScannedItem = "WAITING FOR INPUT...";
  String _statusMessage = "TERMINAL READY";
  Color _statusColor = Colors.green;

  // --- BUSINESS DATA ---
  late int _businessId;
  late String _staffName;
  late String _businessName;

  // --- ANIMATION REQUISITES ---
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _initializeBusinessData();
    _configureAnimations();
    _startConnectivityMonitoring();
    _initializeDataStreaming();
    _loadUserPreferences();
  }

  // --------------------------------------------------------------------------
  // INITIALIZATION LOGIC
  // --------------------------------------------------------------------------

  void _initializeBusinessData() {
    _businessId = widget.user['business_id'] ?? 0;
    _staffName = widget.user['username'] ?? widget.user['name'] ?? 'Staff';
    _businessName = widget.user['business_name'] ?? '1 STOCK';

    // Scanner keeps focus for continuous scanning
    _scannerFocus.addListener(() {
      if (!_scannerFocus.hasFocus && mounted) {
        Future.delayed(const Duration(milliseconds: 700), () {
          if (mounted) _scannerFocus.requestFocus();
        });
      }
    });
  }

  void _configureAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  void _startConnectivityMonitoring() {
    Connectivity().onConnectivityChanged.listen((List<ConnectivityResult> results) {
      if (mounted) {
        setState(() => _isOnline = !results.contains(ConnectivityResult.none));
      }
    });
  }

  Future<void> _loadUserPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _isDarkMode = prefs.getBool('terminal_dark_mode') ?? false);
  }

  void _toggleTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _isDarkMode = !_isDarkMode);
    await prefs.setBool('terminal_dark_mode', _isDarkMode);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _mainController.dispose();
    _scannerFocus.dispose();
    _cartScrollController.dispose();
    super.dispose();
  }

  // --------------------------------------------------------------------------
  // CORE SCAN ENGINE (TRIPLE-LEVEL SEARCH)
  // --------------------------------------------------------------------------

  Future<void> _processScan(String code) async {
    final barcode = code.trim();
    if (barcode.isEmpty || _isLoading) return;

    setState(() {
      _isLoading = true;
      _statusMessage = "SUBIRI INATAFUTA...";
      _statusColor = Colors.blue;
    });

    try {
      // Parallel searches across three tables: Medicines, Other Products, Services
      final results = await Future.wait([
        _supabase.from('medicines').select().eq('item_code', barcode).eq('business_id', _businessId).maybeSingle(),
        _supabase.from('other_product').select().eq('qr_code_url', barcode).eq('business_id', _businessId).maybeSingle(),
        _supabase.from('services').select().eq('qr_code_url', barcode).eq('business_id', _businessId).maybeSingle(),
      ]);

      if (results[0] != null) {
        await _executeStockTransaction(results[0]!, 'MEDICINES');
      } else if (results[1] != null) {
        await _executeStockTransaction(results[1]!, 'OTHER_PRODUCT');
      } else if (results[2] != null) {
        await _executeStockTransaction(results[2]!, 'SERVICES');
      } else {
        _handleTerminalError("BARCODE NOT FOUND: $barcode");
      }
    } catch (e) {
      _handleTerminalError("HAMNA MUUNGANISHO WA DATA");
    } finally {
      _mainController.clear();
      _scannerFocus.requestFocus();
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // --------------------------------------------------------------------------
  // STOCK & CART SYNCHRONIZATION
  // --------------------------------------------------------------------------

  Future<void> _executeStockTransaction(Map<String, dynamic> item, String source) async {
    final String pName = item['name'] ?? item['service_name'] ?? 'ITEM';
    final double pPrice = double.tryParse((item['selling_price'] ?? item['price'] ?? 0).toString()) ?? 0.0;
    final int currentStock = int.tryParse(item['remaining_quantity']?.toString() ?? '0') ?? 0;
    final String targetTable = source.toLowerCase();

    // Prevent sale of empty stock
    if (currentStock <= 0) {
      _notifyUser("OUT OF STOCK: $pName", Colors.red);
      return;
    }

    try {
      // Step 1: Reduce stock at source
      await _supabase.from(targetTable).update({
        'remaining_quantity': currentStock - 1
      }).eq('id', item['id']);

      // Step 2: Sync with temporary Cart
      final existingIndex = _cartItems.indexWhere(
              (e) => e['medicine_id'] == item['id'] && e['source'] == source.toUpperCase()
      );

      if (existingIndex != -1) {
        int newQty = (_cartItems[existingIndex]['quantity'] ?? 0) + 1;
        await _supabase.from('cart').update({'quantity': newQty}).eq('id', _cartItems[existingIndex]['id']);
      } else {
        await _supabase.from('cart').insert({
          'medicine_id': item['id'],
          'medicine_name': pName,
          'price': pPrice,
          'quantity': 1,
          'source': source.toUpperCase(),
          'business_id': _businessId,
          'user_id': widget.user['id'],
          'business_name': _businessName,
          'date_added': DateTime.now().toIso8601String(),
        });
      }

      _notifyUser("ADDED: $pName", Colors.green);
      _autoScrollCart();
      HapticFeedback.lightImpact();

      setState(() {
        _lastScannedItem = pName;
        _statusMessage = "SUCCESS: $pName";
        _statusColor = Colors.green;
      });

    } catch (e) {
      _handleTerminalError("SYNC ERROR: $e");
    }
  }

  // --------------------------------------------------------------------------
  // POPUP UPDATE DIALOG (THE MANUAL OVERRIDE)
  // --------------------------------------------------------------------------

  Future<void> _updateQuantityManually(Map<String, dynamic> cartItem, int newQty) async {
    if (newQty < 1) return;
    setState(() => _isLoading = true);

    try {
      final String sourceTable = cartItem['source'].toString().toLowerCase();
      final int oldQty = cartItem['quantity'] ?? 1;
      final int diff = newQty - oldQty;

      // Check real stock level
      final res = await _supabase.from(sourceTable).select('remaining_quantity').eq('id', cartItem['medicine_id']).single();
      int currentStock = int.tryParse(res['remaining_quantity'].toString()) ?? 0;

      // If increasing qty, ensure stock exists
      if (diff > 0 && currentStock < diff) {
        _notifyUser("INSUFFICIENT STOCK IN YOUR STOCK!", Colors.red);
        return;
      }

      // Perform atomic database update
      await Future.wait([
        _supabase.from(sourceTable).update({'remaining_quantity': currentStock - diff}).eq('id', cartItem['medicine_id']),
        _supabase.from('cart').update({'quantity': newQty}).eq('id', cartItem['id']),
      ]);

      _notifyUser("QUANTITY UPDATED TO $newQty", Colors.blue);
    } catch (e) {
      _notifyUser("ERROR UPDATING STOCK: $e", Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showQuantityEditPopup(Map<String, dynamic> item) {
    final TextEditingController _editController = TextEditingController(text: item['quantity'].toString());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: _isDarkMode ? const Color(0xFF1E293B) : Colors.white,
        title: Row(
          children: [
            const Icon(Icons.edit_note, color: Colors.blue),
            const SizedBox(width: 10),
            Text("UPDATE QUANTITY", style: GoogleFonts.inter(fontWeight: FontWeight.bold, fontSize: 18, color: _isDarkMode ? Colors.white : Colors.black)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(item['medicine_name'], style: const TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 20),
            TextField(
              controller: _editController,
              autofocus: true,
              keyboardType: TextInputType.number,
              style: TextStyle(color: _isDarkMode ? Colors.white : Colors.black, fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                filled: true,
                fillColor: _isDarkMode ? Colors.black12 : Colors.grey[100],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                prefixIcon: const Icon(Icons.shopping_bag_outlined),
              ),
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("CANCEL", style: TextStyle(color: Colors.red))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () {
              int? val = int.tryParse(_editController.text);
              if (val != null && val > 0) {
                Navigator.pop(context);
                _updateQuantityManually(item, val);
              }
            },
            child: const Text("UPDATE", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    ).then((_) => _scannerFocus.requestFocus());
  }

  // --------------------------------------------------------------------------
  // STOCK RESTORATION ON ITEM REMOVAL
  // --------------------------------------------------------------------------

  Future<void> _removeFromCart(Map<String, dynamic> cartItem) async {
    setState(() => _isLoading = true);
    try {
      final String table = cartItem['source'].toString().toLowerCase();
      final int qtyToReturn = cartItem['quantity'] ?? 1;

      // Get current stock
      final stockData = await _supabase.from(table).select('remaining_quantity').eq('id', cartItem['medicine_id']).single();
      int currentStock = int.tryParse(stockData['remaining_quantity'].toString()) ?? 0;

      // Restore stock and delete entry
      await Future.wait([
        _supabase.from(table).update({'remaining_quantity': currentStock + qtyToReturn}).eq('id', cartItem['medicine_id']),
        _supabase.from('cart').delete().eq('id', cartItem['id']),
      ]);

      _notifyUser("STOCK RESTORED TO $table", Colors.blueGrey);
    } catch (e) {
      _notifyUser("FAILED TO REMOVE ITEM", Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // --------------------------------------------------------------------------
  // SUBSYSTEM HELPERS
  // --------------------------------------------------------------------------

  void _initializeDataStreaming() {
    _supabase.from('cart').stream(primaryKey: ['id']).listen((data) {
      if (mounted) {
        setState(() {
          _cartItems = data.where((i) => i['user_id'] == widget.user['id']).toList();
        });
      }
    });
  }

  void _autoScrollCart() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_cartScrollController.hasClients) {
        _cartScrollController.animateTo(
          _cartScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeOutCirc,
        );
      }
    });
  }

  void _handleTerminalError(String msg) {
    setState(() {
      _statusMessage = msg;
      _statusColor = Colors.red;
    });
    _notifyUser(msg, Colors.red);
    HapticFeedback.vibrate();
  }

  void _notifyUser(String msg, Color color) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, textAlign: TextAlign.center, style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.symmetric(horizontal: 100, vertical: 40),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // --------------------------------------------------------------------------
  // UI LAYOUT CONSTRUCTION
  // --------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    // Hesabu ya jumla ya kikapu
    double grandTotal = _cartItems.fold(0, (sum, i) => sum + (double.tryParse(i['price'].toString())! * i['quantity']));

    // Theme settings kulingana na Dark Mode
    final bgTheme = _isDarkMode ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9);
    final cardTheme = _isDarkMode ? const Color(0xFF1E293B) : Colors.white;
    final textTheme = _isDarkMode ? Colors.white : const Color(0xFF1E293B);

    // Rangi maalum kwa ajili ya AppBar yako
    const Color appBarColor = Colors.blueAccent;
    const Color appBarTextColor = Colors.white;

    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.f12): () => Navigator.push(context, MaterialPageRoute(builder: (c) => CartScreen(user: widget.user))),
        const SingleActivator(LogicalKeyboardKey.escape): () => _mainController.clear(),
      },
      child: Scaffold(
        backgroundColor: bgTheme,

        // --- APP BAR FULL IMPLEMENTATION ---
        appBar: AppBar(
          backgroundColor: appBarColor,
          elevation: 0,
          toolbarHeight: 100, // Kimo kilichoongezwa ili kubeba fontSize 30 na Row
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Jina la Biashara (e.g., Arusha Online Store)
              Text(
                  _businessName,
                  style: GoogleFonts.inter(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      color: appBarTextColor,
                      letterSpacing: -1
                  )
              ),
              const SizedBox(height: 4),
              // Status ya Online/Offline
              Row(
                children: [
                  Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                          color: _isOnline ? Colors.greenAccent : Colors.redAccent,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: (_isOnline ? Colors.green : Colors.red).withOpacity(0.4),
                              blurRadius: 5,
                              spreadRadius: 2,
                            )
                          ]
                      )
                  ),
                  const SizedBox(width: 10),
                  Text(
                      _isOnline ? "STOCK AND INVENTORY SOFTWARE: ONLINE" : "CONNECTION LOST",
                      style: GoogleFonts.inter(
                          fontSize: 12,
                          color: Colors.white.withOpacity(0.8),
                          fontWeight: FontWeight.bold
                      )
                  ),
                ],
              ),
            ],
          ),
          actions: [
            // Unaweza kuongeza kitufe cha kusearch au profile hapa
            Padding(
              padding: const EdgeInsets.only(right: 20),
              child: CircleAvatar(
                backgroundColor: Colors.white.withOpacity(0.2),
                child: const Icon(Icons.person, color: Colors.white),
              ),
            ),
          ],
        ),

        body: Row(
          children: [
            // LEFT SIDE: SCANNER & DASHBOARD
            Expanded(
                flex: 3,
                child: _buildScannerInterface(textTheme, cardTheme)
            ),

            // RIGHT SIDE: REAL-TIME BASKET (GRAND TOTAL)
            _buildBasketPanel(grandTotal, cardTheme, textTheme),
          ],
        ),
      ),
    );
  }

  Widget _buildScannerInterface(Color textCol, Color cardCol) {
    return Container(
      padding: const EdgeInsets.all(50),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTerminalBranding(textCol),
          const Spacer(),

          Center(
            child: Column(
              children: [
                ScaleTransition(
                  scale: _pulseAnimation,
                  child: Container(
                    padding: const EdgeInsets.all(45),
                    decoration: BoxDecoration(color: Colors.blue.withOpacity(0.06), shape: BoxShape.circle),
                    child: const Icon(Icons.qr_code_scanner_outlined, size: 110, color: Colors.blue),
                  ),
                ),
                const SizedBox(height: 60),
                _buildInputFrame(cardCol, textCol),
                const SizedBox(height: 30),
                _buildTerminalStatusBar(),
              ],
            ),
          ),

          const Spacer(),
          _buildActivityFooter(cardCol, textCol),
        ],
      ),
    );
  }

  Widget _buildTerminalBranding(Color textCol) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Text(_businessName, style: GoogleFonts.inter(fontSize: 30, fontWeight: FontWeight.w900, color: textCol, letterSpacing: -1)),
            Row(
              children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: _isOnline ? Colors.green : Colors.red, shape: BoxShape.circle)),
                const SizedBox(width: 10),
                Text(_isOnline ? "STATUS: ONLINE" : "CONNECTION LOST", style: GoogleFonts.inter(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
        Row(
          children: [
            _buildTopStat("STAFF", _staffName, Icons.verified_user_outlined),
            const SizedBox(width: 15),
            IconButton(onPressed: _toggleTheme, icon: Icon(_isDarkMode ? Icons.light_mode_rounded : Icons.dark_mode_rounded, color: textCol)),
          ],
        )
      ],
    );
  }

  Widget _buildInputFrame(Color cardCol, Color textCol) {
    return Container(
      width: 700,
      decoration: BoxDecoration(color: cardCol, borderRadius: BorderRadius.circular(40), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 60)]),
      child: TextField(
        controller: _mainController,
        focusNode: _scannerFocus,
        autofocus: true,
        onSubmitted: (v) => _processScan(v),
        style: GoogleFonts.jetBrainsMono(fontSize: 38, fontWeight: FontWeight.bold, color: textCol, letterSpacing: 6),
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          hintText: "SCAN PRODUCT",
          hintStyle: GoogleFonts.inter(fontSize: 22, color: Colors.grey[300], letterSpacing: 3),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 45),
        ),
      ),
    );
  }

  Widget _buildTerminalStatusBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
      decoration: BoxDecoration(color: _statusColor.withOpacity(0.08), borderRadius: BorderRadius.circular(20)),
      child: Text(_statusMessage.toUpperCase(), style: GoogleFonts.inter(color: _statusColor, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1.5)),
    );
  }

  Widget _buildActivityFooter(Color cardCol, Color textCol) {
    return Container(
      padding: const EdgeInsets.all(35),
      decoration: BoxDecoration(color: cardCol, borderRadius: BorderRadius.circular(35), border: Border.all(color: Colors.grey.withOpacity(0.1))),
      child: Row(
        children: [
          const CircleAvatar(backgroundColor: Colors.blue, radius: 25, child: Icon(Icons.shopping_bag, color: Colors.white)),
          const SizedBox(width: 25),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("LAST ITEM SCANNED", style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
              Text(_lastScannedItem, style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w800, color: textCol)),
            ],
          ),
          const Spacer(),
          _buildKeyHint("F12", "CHECKOUT"),
          const SizedBox(width: 15),
          _buildKeyHint("ESC", "CLEAR"),
        ],
      ),
    );
  }

  Widget _buildBasketPanel(double total, Color cardCol, Color textCol) {
    return Container(
      width: 580,
      decoration: BoxDecoration(color: cardCol, border: Border(left: BorderSide(color: Colors.grey.withOpacity(0.1)))),
      child: Column(
        children: [
          _buildBasketHeader(textCol),
          Expanded(child: _buildBasketItems(textCol)),
          _buildBasketSummary(total, textCol),
        ],
      ),
    );
  }

  Widget _buildBasketHeader(Color textCol) {
    return Container(
      padding: const EdgeInsets.all(50),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("ITEMS IN BASKET", style: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.w900, color: textCol)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
            decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(15)),
            child: Text("${_cartItems.length} ITEMS", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
          )
        ],
      ),
    );
  }

  Widget _buildBasketItems(Color textCol) {
    if (_cartItems.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_shopping_cart_rounded, size: 80, color: Colors.grey[200]),
            const SizedBox(height: 20),
            Text("NO ITEMS SCANNED", style: GoogleFonts.inter(color: Colors.grey[400], letterSpacing: 2, fontWeight: FontWeight.bold)),
          ],
        ),
      );
    }
    return ListView.builder(
      controller: _cartScrollController,
      padding: const EdgeInsets.symmetric(horizontal: 35),
      itemCount: _cartItems.length,
      itemBuilder: (context, index) => _buildBasketTile(_cartItems[index], textCol),
    );
  }

  Widget _buildBasketTile(Map<String, dynamic> item, Color textCol) {
    return SlideInRight(
      duration: const Duration(milliseconds: 400),
      child: Container(
        margin: const EdgeInsets.only(bottom: 18),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: _isDarkMode ? Colors.white.withOpacity(0.04) : const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(30)),
        child: Row(
          children: [
            // INTERACTIVE QUANTITY BUBBLE
            Tooltip(
              message: "Click to edit quantity",
              child: GestureDetector(
                onTap: () => _showQuantityEditPopup(item),
                child: Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(color: Colors.blue, borderRadius: BorderRadius.circular(15), boxShadow: [BoxShadow(color: Colors.blue.withOpacity(0.3), blurRadius: 10)]),
                  alignment: Alignment.center,
                  child: Text("${item['quantity']}", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
            const SizedBox(width: 25),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                      item['medicine_name'],
                      style: GoogleFonts.inter(fontWeight: FontWeight.bold, fontSize: 18, color: textCol)
                  ),
                  Text(
                    // HAPA NDIPO MABADILIKO YALIPO:
                      item['source'] == 'MEDICINES' ? 'NORMAL PRODUCT' : item['source'],
                      style: const TextStyle(
                          fontSize: 11,
                          color: Colors.blue,
                          fontWeight: FontWeight.bold
                      )
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(NumberFormat('#,###').format(item['price'] * item['quantity']), style: GoogleFonts.inter(fontWeight: FontWeight.w900, color: Colors.blue, fontSize: 18)),
                IconButton(icon: const Icon(Icons.delete_forever_outlined, color: Colors.redAccent, size: 24), onPressed: () => _removeFromCart(item)),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildBasketSummary(double total, Color textCol) {
    return Container(
      padding: const EdgeInsets.all(55),
      decoration: BoxDecoration(color: _isDarkMode ? Colors.black12 : Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 40, offset: const Offset(0, -15))]),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("TOTAL PAYABLE", style: GoogleFonts.inter(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.grey)),
              Text("${NumberFormat('#,###').format(total)} TSH", style: GoogleFonts.inter(fontSize: 38, fontWeight: FontWeight.w900, color: textCol)),
            ],
          ),
          const SizedBox(height: 45),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[700],
              minimumSize: const Size(double.infinity, 90),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(35)),
              elevation: 0,
            ),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (c) => CartScreen(user: widget.user))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.check_circle_outline, color: Colors.white, size: 30),
                const SizedBox(width: 20),
                Text("PROCESS ORDER (F12)", style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopStat(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(color: Colors.blue.withOpacity(0.06), borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.blue),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 9, color: Colors.grey, fontWeight: FontWeight.bold)),
              Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildKeyHint(String key, String action) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      decoration: BoxDecoration(color: Colors.grey.withOpacity(0.08), borderRadius: BorderRadius.circular(12)),
      child: Text("$key: $action", style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
    );
  }
}