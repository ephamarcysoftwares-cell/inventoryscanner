import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:dropdown_search/dropdown_search.dart';
import '../FOTTER/CurvedRainbowBar.dart';

class EditMedicineScreen extends StatefulWidget {
  final int id;
  final String name;
  final String company;
  final int total_quantity;
  final int remaining_quantity;
  final double buy;
  final double price;
  final String batchNumber;
  final String manufacturedDate;
  final String expiryDate;
  final String added_by;
  final double discount;
  final String unit;
  final String businessName;
  final Map<String, dynamic> user; // ✅ Inatambulika sasa
  final String? qr_code_url;

  const EditMedicineScreen({
    super.key,
    required this.id,
    required this.name,
    required this.company,
    required this.total_quantity,
    required this.remaining_quantity,
    required this.buy,
    required this.price,
    required this.batchNumber,
    required this.manufacturedDate,
    required this.expiryDate,
    required this.added_by,
    required this.discount,
    required this.unit,
    required this.businessName,
    required this.user,
    this.qr_code_url, required added_time, required int synced,
  });

  @override
  _EditMedicineScreenState createState() => _EditMedicineScreenState();
}

class _EditMedicineScreenState extends State<EditMedicineScreen> {
  late TextEditingController nameController, totalQtyController, remQtyController,
      buyController, priceController, batchController, mfgDateController,
      expDateController, discountController, qrController;

  bool _isDarkMode = false;
  bool _isLoading = false;
  List<String> companies = [];
  String? selectedCompany;
  String? _selectedUnit;

  @override
  void initState() {
    super.initState();
    _loadTheme();

    // Initializing Controllers na data kutoka kwa widget
    nameController = TextEditingController(text: widget.name);
    totalQtyController = TextEditingController(text: widget.total_quantity.toString());
    remQtyController = TextEditingController(text: widget.remaining_quantity.toString());
    buyController = TextEditingController(text: widget.buy.toString());
    priceController = TextEditingController(text: widget.price.toString());
    batchController = TextEditingController(text: widget.batchNumber);
    mfgDateController = TextEditingController(text: widget.manufacturedDate);
    expDateController = TextEditingController(text: widget.expiryDate);
    discountController = TextEditingController(text: widget.discount.toString());
    qrController = TextEditingController(text: widget.qr_code_url ?? "");

    selectedCompany = widget.company;
    _selectedUnit = widget.unit;

    _fetchCompanies();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _isDarkMode = prefs.getBool('darkMode') ?? false);
  }

  Future<void> _fetchCompanies() async {
    try {
      final response = await Supabase.instance.client.from('companies').select('name');
      if (response != null) {
        setState(() {
          companies = (response as List).map((e) => e['name'].toString()).toList();
          // ✅ Kinga: Kama STOCK haipo kwenye list, iongeze
          if (!companies.contains("STOCK")) companies.add("STOCK");
          // Kinga: Hakikisha kampuni iliyopo sasa ipo kwenye list kuzuia Dropdown error
          if (selectedCompany != null && !companies.contains(selectedCompany)) {
            companies.add(selectedCompany!);
          }
        });
      }
    } catch (e) {
      debugPrint("Error fetching companies: $e");
    }
  }

  Future<void> _selectDate(TextEditingController controller) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => controller.text = DateFormat('yyyy-MM-dd').format(picked));
    }
  }

  // --- UPDATE LOGIC ---
  Future<void> updateMedicine() async {
    setState(() => _isLoading = true);
    try {
      final supabase = Supabase.instance.client;
      final userId = supabase.auth.currentUser!.id;

      // 1. Pata Profile ya mtumiaji aliyelogin sasa hivi
      final userProfile = await supabase.from('users').select('sub_business_name').eq('id', userId).maybeSingle();
      String? rawSub = userProfile?['sub_business_name']?.toString().trim();

      // ✅ AUTOMATIC NULL: Kama tawi ni 'NULL', badilisha kuwa NULL ya kweli (null)
      dynamic finalSub = (rawSub == null || rawSub.isEmpty || rawSub.toUpperCase() == 'NULL') ? null : rawSub;

      // 2. Kufanya Update kwenye Table ya Medicines
      await supabase.from('medicines').update({
        'name': nameController.text.trim().toUpperCase(),
        'company': selectedCompany ?? 'STOCK',
        'total_quantity': int.tryParse(totalQtyController.text) ?? 0,
        'remaining_quantity': int.tryParse(remQtyController.text) ?? 0,
        'buy': double.tryParse(buyController.text) ?? 0.0,
        'price': double.tryParse(priceController.text) ?? 0.0,
        'batch_number': batchController.text.trim(),
        'manufacture_date': mfgDateController.text.isEmpty ? null : mfgDateController.text,
        'expiry_date': expDateController.text.isEmpty ? null : expDateController.text,
        'discount': double.tryParse(discountController.text) ?? 0.0,
        'unit': _selectedUnit,
        'qr_code_url': qrController.text.trim(), // ✅ Update QR Code URL
        'sub_business_name': finalSub, // Inasafishwa na trigger pia
        'last_updated': DateTime.now().toIso8601String(),
        'synced': false,
      }).eq('id', widget.id);

      if (mounted) {
        Navigator.pop(context, true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ Bidhaa imesasishwa kikamilifu!"), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Imeshindwa kusave: $e"), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color txtCol = _isDarkMode ? Colors.white : Colors.black87;
    final Color cardBg = _isDarkMode ? const Color(0xFF1E293B) : Colors.white;

    return Scaffold(
      backgroundColor: _isDarkMode ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
      appBar: AppBar(
        title: const Text(
          "EDIT PRODUCT",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w300,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        // Kuhakikisha icons (kama back button) ni nyeupe
        iconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF0D47A1), // Blue iliyokoza (Deep Blue)
                Color(0xFF1976D2), // Blue ya kati (Primary Blue)
                Color(0xFF42A5F5), // Light Blue
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // QR PREVIEW
            if (qrController.text.isNotEmpty) _buildQRView(),

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(15)),
              child: Column(
                children: [
                  _input(nameController, "Product Name", Icons.medication, txtCol),

                  Row(
                    children: [
                      Expanded(child: _input(qrController, "QR Code / URL", Icons.qr_code, txtCol)),
                      IconButton(
                        onPressed: () async {
                          String res = await FlutterBarcodeScanner.scanBarcode("#673AB7", "Ghairi", true, ScanMode.BARCODE);
                          if (res != '-1') setState(() => qrController.text = res);
                        },
                        icon: const Icon(Icons.qr_code_scanner, color: Colors.green, size: 30),
                      ),
                    ],
                  ),

                  _drop("Company", selectedCompany, companies, (v) => setState(() => selectedCompany = v), txtCol),

                  Row(
                    children: [
                      Expanded(child: _input(totalQtyController, "Total Qty", Icons.inventory, txtCol, type: TextInputType.number)),
                      const SizedBox(width: 10),
                      Expanded(child: _input(remQtyController, "Rem Qty", Icons.shopping_cart, txtCol, type: TextInputType.number)),
                    ],
                  ),

                  Row(
                    children: [
                      Expanded(child: _input(buyController, "Buy Price", Icons.payments, txtCol, type: TextInputType.number)),
                      const SizedBox(width: 10),
                      Expanded(child: _input(priceController, "Sell Price", Icons.sell, txtCol, type: TextInputType.number)),
                    ],
                  ),

                  _date(mfgDateController, "Manufacture Date", txtCol),
                  _date(expDateController, "Expiry Date", txtCol),
                  _unitDrop(txtCol),
                ],
              ),
            ),
            const SizedBox(height: 25),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                onPressed: updateMedicine,
                icon: const Icon(Icons.save, color: Colors.white),
                label: const Text("SAVE CHANGES", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF311B92), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: const CurvedRainbowBar(height: 40),
    );
  }

  // --- WIDGET HELPERS ---

  Widget _buildQRView() {
    return Column(
      children: [
        const Icon(Icons.qr_code_2, size: 80, color: Colors.deepPurple),
        Text("Current QR: ${qrController.text}", style: const TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 15),
      ],
    );
  }

  Widget _input(TextEditingController c, String l, IconData i, Color col, {TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: c, keyboardType: type, style: TextStyle(color: col),
        decoration: InputDecoration(
          labelText: l, prefixIcon: Icon(i, color: Colors.deepPurple),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  Widget _date(TextEditingController c, String l, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: c, readOnly: true, onTap: () => _selectDate(c), style: TextStyle(color: col),
        decoration: InputDecoration(
          labelText: l, prefixIcon: const Icon(Icons.calendar_month, color: Colors.deepPurple),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  Widget _drop(String l, String? v, List<String> items, Function(String?) onChg, Color col) {
    // Kinga ya mwisho ya Dropdown item mismatch
    String? safeValue = (v != null && items.contains(v)) ? v : (items.isNotEmpty ? items.first : null);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: DropdownButtonFormField<String>(
        value: safeValue,
        items: items.toSet().map((e) => DropdownMenuItem(value: e, child: Text(e, style: TextStyle(color: col)))).toList(),
        onChanged: onChg,
        decoration: InputDecoration(labelText: l, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
      ),
    );
  }

  Widget _unitDrop(Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: DropdownSearch<String>(
        items: const ['Dozen', 'KG', 'Per Item', 'Liter', 'Pics', 'Box', 'Bottle', 'Tablet', 'Capsule', 'Strip'],
        selectedItem: _selectedUnit,
        onChanged: (v) => setState(() => _selectedUnit = v),
        dropdownDecoratorProps: DropDownDecoratorProps(
          dropdownSearchDecoration: InputDecoration(labelText: "Unit", border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
        ),
      ),
    );
  }
}