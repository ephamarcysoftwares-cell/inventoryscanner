import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart';

/// Hii ni Page kamilifu ya Kusimamia na Ku-Print QR/Barcodes
/// Inajumuisha kila kitu kuanzia Database hadi PDF Export
class ViewAllQRCodesPage extends StatefulWidget {
  final Map<String, dynamic> user;
  const ViewAllQRCodesPage({super.key, required this.user});

  @override
  State<ViewAllQRCodesPage> createState() => _ViewAllQRCodesPageState();
}

class _ViewAllQRCodesPageState extends State<ViewAllQRCodesPage> with SingleTickerProviderStateMixin {
  // --- DATABASE & DATA STATE ---
  List<Map<String, dynamic>> _allItems = [];
  List<Map<String, dynamic>> _filteredItems = [];
  bool _isLoading = true;
  String _selectedTable = "ZOTE";
  String _searchQuery = "";
  int _missingCount = 0;
  bool _isVerticalLayout = true;

  // Stats
  int _totalMeds = 0;
  int _totalOthers = 0;
  int _totalServices = 0;

  // Filter States
  DateTime? _startDate;
  DateTime? _endDate;
  int? _currentUserBusinessId;
  String? businessName;
  String subBusinessName = "Main Branch";

  // UI Styling
  final Color bgWhite = const Color(0xFFF8FAFC);
  final Color textBlack = const Color(0xFF1E293B);
  final Color primaryTeal = const Color(0xFF0D9488);
  final Color lightGrey = const Color(0xFFF1F5F9);

  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _initializePage();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _initializePage() async {
    await getBusinessInfo();
    await _fetchAllData();
  }

  // --------------------------------------------------------------------------
  // 1. BUSINESS INFO & SUPABASE LOGIC
  // --------------------------------------------------------------------------

  Future<void> getBusinessInfo() async {
    try {
      final supabase = Supabase.instance.client;
      final user = supabase.auth.currentUser;
      if (user == null) return;

      final userProfile = await supabase
          .from('users')
          .select('business_id, sub_business_name')
          .eq('id', user.id)
          .maybeSingle();

      if (userProfile != null) {
        if (mounted) {
          setState(() {
            _currentUserBusinessId = userProfile['business_id'];
            subBusinessName = userProfile['sub_business_name'] ?? "Main Branch";
          });
        }

        final bData = await supabase
            .from('businesses')
            .select('business_name')
            .eq('id', _currentUserBusinessId!)
            .maybeSingle();

        if (mounted && bData != null) {
          setState(() => businessName = bData['business_name']);
        }
      }
    } catch (e) {
      debugPrint('Info Fetch Error: $e');
    }
  }

  Future<void> _fetchAllData() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    final supabase = Supabase.instance.client;
    final bId = _currentUserBusinessId ?? widget.user['business_id'];

    try {
      // Tunatengeneza queries za meza tatu tofauti
      var medQuery = supabase.from('medicines').select('id, name, item_code, added_time').eq('business_id', bId);
      var otherQuery = supabase.from('other_product').select('id, name, qr_code_url, date_added').eq('business_id', bId);
      var serviceQuery = supabase.from('services').select('id, name, added_time').eq('business_id', bId);

      // Apply Date Filters if selected
      if (_startDate != null && _endDate != null) {
        String start = _startDate!.toIso8601String();
        String end = _endDate!.add(const Duration(days: 1)).toIso8601String();
        medQuery = medQuery.gte('added_time', start).lt('added_time', end);
        otherQuery = otherQuery.gte('date_added', start).lt('date_added', end);
        serviceQuery = serviceQuery.gte('added_time', start).lt('added_time', end);
      }

      final responses = await Future.wait([medQuery, otherQuery, serviceQuery]);

      List<Map<String, dynamic>> combined = [];
      int missing = 0;

      // Processing Medicines
      final medList = responses[0] as List;
      _totalMeds = medList.length;
      for (var row in medList) {
        String c = row['item_code']?.toString() ?? "";
        if (c.isEmpty || c == 'null') { missing++; c = ""; }
        combined.add({
          'id': row['id'], 'name': row['name'], 'code': c,
          'type': 'NORMAL', 'table': 'medicines', 'col': 'item_code'
        });
      }

      // Processing Other Products
      final otherList = responses[1] as List;
      _totalOthers = otherList.length;
      for (var row in otherList) {
        String c = row['qr_code_url']?.toString() ?? "";
        if (c.isEmpty || c == 'null') { missing++; c = ""; }
        combined.add({
          'id': row['id'], 'name': row['name'], 'code': c,
          'type': 'OTHER', 'table': 'other_product', 'col': 'qr_code_url'
        });
      }

      // Processing Services
      final serviceList = responses[2] as List;
      _totalServices = serviceList.length;
      for (var row in serviceList) {
        // Services mara nyingi hutumia ID kama QR kwa default
        combined.add({
          'id': row['id'], 'name': row['name'], 'code': row['id'].toString(),
          'type': 'SERVICE', 'table': 'services', 'col': 'id'
        });
      }

      if (mounted) {
        setState(() {
          _allItems = combined;
          _missingCount = missing;
          _isLoading = false;
          _setStateFilter();
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
      _showSnackBar("Kosa la kuunganisha: $e", Colors.red);
    }
  }

  // --------------------------------------------------------------------------
  // 2. SEARCH & FILTER LOGIC
  // --------------------------------------------------------------------------

  void _setStateFilter() {
    List<Map<String, dynamic>> temp = [];

    // 1. Table Filter
    if (_selectedTable == "ZOTE") {
      temp = List.from(_allItems);
    } else {
      temp = _allItems.where((i) => i['type'] == _selectedTable).toList();
    }

    // 2. Search Query
    if (_searchQuery.isNotEmpty) {
      temp = temp.where((i) =>
      i['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
          i['code'].toString().toLowerCase().contains(_searchQuery.toLowerCase())
      ).toList();
    }

    setState(() => _filteredItems = temp);
  }

  void _showSnackBar(String msg, Color col) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: col, behavior: SnackBarBehavior.floating),
    );
  }

  // --------------------------------------------------------------------------
  // 3. PRINTING DIALOG & PDF GENERATION (CORE)
  // --------------------------------------------------------------------------

  void _askPrintType() {
    if (_filteredItems.isEmpty) {
      _showSnackBar("Hakuna bidhaa za ku-print!", Colors.orange);
      return;
    }

    showDialog(
      context: context,
      builder: (context) {
        bool useBarcode = false;
        bool isLarge = false;

        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Row(
                children: [
                  Icon(Icons.print, color: primaryTeal),
                  const SizedBox(width: 10),
                  const Text("Print Configuration"),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text("Chagua mfumo wa kodi na saizi ya karatasi:"),
                  const SizedBox(height: 15),

                  // QR vs BARCODE
                  Container(
                    decoration: BoxDecoration(color: lightGrey, borderRadius: BorderRadius.circular(10)),
                    child: Column(
                      children: [
                        RadioListTile<bool>(
                          title: const Text("QR Code (Kawaida)"),
                          value: false,
                          groupValue: useBarcode,
                          activeColor: primaryTeal,
                          onChanged: (v) => setDialogState(() => useBarcode = v!),
                        ),
                        RadioListTile<bool>(
                          title: const Text("Barcode (Code 128)"),
                          value: true,
                          groupValue: useBarcode,
                          activeColor: primaryTeal,
                          onChanged: (v) => setDialogState(() => useBarcode = v!),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 15),

                  // SIZE SELECTION
                  Row(
                    children: [
                      const Text("Stika Kubwa?"),
                      const Spacer(),
                      Switch(
                        value: isLarge,
                        onChanged: (v) => setDialogState(() => isLarge = v),
                        activeColor: primaryTeal,
                      ),
                    ],
                  ),
                  const Divider(),
                  Text("Zipo bidhaa ${_filteredItems.length} zitakazochapwa.", style: const TextStyle(fontSize: 11, fontStyle: FontStyle.italic)),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("GHAIRI", style: TextStyle(color: Colors.red.shade400)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: textBlack,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    _executePrint(isLarge: isLarge, useBarcode: useBarcode);
                  },
                  child: const Text("TAYARI", style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _executePrint({required bool isLarge, required bool useBarcode}) async {
    final pdf = pw.Document();

    final List<Map<String, dynamic>> itemsToPrint = _filteredItems
        .where((i) => i['code'] != null && i['code'].toString().isNotEmpty)
        .toList();

    if (itemsToPrint.isEmpty) {
      _showSnackBar("Bidhaa zilizochaguliwa hazina kodi!", Colors.red);
      return;
    }

    // Sort A-Z
    itemsToPrint.sort((a, b) => a['name'].toString().trim().toUpperCase()
        .compareTo(b['name'].toString().trim().toUpperCase()));

    // Idadi kwa kila ukurasa
    int itemsPerPage = isLarge ? 4 : (_isVerticalLayout ? 10 : 24);

    for (var i = 0; i < itemsToPrint.length; i += itemsPerPage) {
      int end = (i + itemsPerPage < itemsToPrint.length) ? i + itemsPerPage : itemsToPrint.length;
      final chunk = itemsToPrint.sublist(i, end);

      pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        build: (pw.Context context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _buildPdfHeader(useBarcode),
            pw.SizedBox(height: 15),
            if (isLarge)
              pw.Column(children: chunk.map((item) => _pdfLargeItem(item, useBarcode)).toList())
            else if (_isVerticalLayout)
              pw.Column(children: chunk.map((item) => _pdfRowItem(item, useBarcode)).toList())
            else
              pw.Wrap(spacing: 12, runSpacing: 12, children: chunk.map((item) => _pdfGridItem(item, useBarcode)).toList()),

            pw.Spacer(),
            _buildPdfFooter(context),
          ],
        ),
      ));
    }

    await Printing.layoutPdf(
        onLayout: (format) async => pdf.save(),
        name: 'Inventory_Export_${DateTime.now().millisecond}'
    );
  }

  // --------------------------------------------------------------------------
  // 4. PDF BUILDING BLOCKS
  // --------------------------------------------------------------------------

  pw.Widget _buildPdfHeader(bool isBarcode) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: const pw.BoxDecoration(
        color: PdfColors.teal900,
        borderRadius: pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(businessName?.toUpperCase() ?? "INVENTORY SYSTEM",
                  style: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 12)),
              pw.Text(subBusinessName, style: pw.TextStyle(color: PdfColors.teal100, fontSize: 8)),
            ],
          ),
          pw.Text(isBarcode ? "BARCODE REPORT" : "QR CODE REPORT",
              style: pw.TextStyle(color: PdfColors.white, fontSize: 10)),
        ],
      ),
    );
  }

  pw.Widget _buildPdfFooter(pw.Context context) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text("Generated on: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}",
            style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600)),
        pw.Text("Page ${context.pageNumber} of ${context.pagesCount}",
            style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600)),
      ],
    );
  }

  pw.Widget _pdfLargeItem(Map<String, dynamic> item, bool isBarcode) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 12),
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(10)),
      ),
      child: pw.Row(
        children: [
          pw.BarcodeWidget(
            barcode: isBarcode ? pw.Barcode.code128() : pw.Barcode.qrCode(),
            data: item['code'],
            width: isBarcode ? 160 : 100,
            height: 80,
          ),
          pw.SizedBox(width: 25),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(item['name'].toString().toUpperCase(),
                    style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 6),
                pw.Text("CODE: ${item['code']}",
                    style: pw.TextStyle(fontSize: 12, color: PdfColors.teal900, fontWeight: pw.FontWeight.bold)),
                pw.Text("Category: ${item['type']}", style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _pdfRowItem(Map<String, dynamic> item, bool isBarcode) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 8),
      padding: const pw.EdgeInsets.all(6),
      decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey200))),
      child: pw.Row(
        children: [
          pw.BarcodeWidget(
            barcode: isBarcode ? pw.Barcode.code128() : pw.Barcode.qrCode(),
            data: item['code'],
            width: isBarcode ? 90 : 45,
            height: 40,
          ),
          pw.SizedBox(width: 20),
          pw.Expanded(
            child: pw.Text(item['name'], style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Text(item['code'], style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        ],
      ),
    );
  }

  pw.Widget _pdfGridItem(Map<String, dynamic> item, bool isBarcode) {
    return pw.Container(
      width: 120,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey200), borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4))),
      child: pw.Column(
        mainAxisSize: pw.MainAxisSize.min,
        children: [
          pw.BarcodeWidget(
            barcode: isBarcode ? pw.Barcode.code128() : pw.Barcode.qrCode(),
            data: item['code'],
            width: 80,
            height: 50,
          ),
          pw.SizedBox(height: 5),
          pw.Text(item['name'],
              style: const pw.TextStyle(fontSize: 7), textAlign: pw.TextAlign.center, maxLines: 2),
          pw.Text(item['code'],
              style: const pw.TextStyle(fontSize: 6, color: PdfColors.grey500)),
        ],
      ),
    );
  }

  // --------------------------------------------------------------------------
  // 5. HELPER LOGIC: GENERATE CODES FOR MISSING ITEMS
  // --------------------------------------------------------------------------

  Future<void> _generateCodesForMissing() async {
    final supabase = Supabase.instance.client;
    int successCount = 0;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    try {
      for (var item in _allItems) {
        if (item['code'].isEmpty) {
          // Generate Random Code like ITM123456
          String newCode = "ITM${Random().nextInt(899999) + 100000}";

          await supabase
              .from(item['table'])
              .update({item['col']: newCode})
              .eq('id', item['id']);

          successCount++;
        }
      }

      Navigator.pop(context); // Close loader
      _fetchAllData(); // Refresh list
      _showSnackBar("Kodi $successCount zimetengenezwa!", Colors.green);
    } catch (e) {
      Navigator.pop(context);
      _showSnackBar("Kosa: $e", Colors.red);
    }
  }

  // --------------------------------------------------------------------------
  // 6. UI BUILDING (FLUTTER)
  // --------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgWhite,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildQuickStats(),
          _buildFilterBar(),
          _buildDateSection(),
          if (_missingCount > 0) _buildMissingWarning(),

          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _buildMainList(),
          ),
        ],
      ),
      floatingActionButton: _buildFAB(),
    );
  }

  // Hakikisha return type ni PreferredSizeWidget
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            businessName?.toUpperCase() ?? "STORE MANAGER",
            style: const TextStyle(
              color: Colors.white, // Text White
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Text(
            "Scanning & Inventory Control",
            style: TextStyle(
              color: Colors.white70, // Text White (slightly faded)
              fontSize: 10,
            ),
          ),
        ],
      ),
      // BACKGROUND LIGHT BLUE
      backgroundColor: Colors.blue.shade400,
      elevation: 0,
      centerTitle: true,
      // Leading Icon White
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        // Action Icon White
        IconButton(
          icon: const Icon(Icons.refresh_rounded, color: Colors.white),
          onPressed: _fetchAllData,
        ),
      ],
    );
  }
  Widget _buildQuickStats() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem("ZOTE", _allItems.length.toString(), Colors.blue),
          _statDivider(),
          _statItem("BILA KODI", _missingCount.toString(), Colors.red),
          _statDivider(),
          _statItem("MEDS", _totalMeds.toString(), Colors.teal),
        ],
      ),
    );
  }

  Widget _statItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(value, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _statDivider() => Container(height: 30, width: 1, color: lightGrey);

  Widget _buildFilterBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          TextField(
            onChanged: (v) { _searchQuery = v; _setStateFilter(); },
            decoration: InputDecoration(
              hintText: "Search items or codes...",
              prefixIcon: const Icon(Icons.search, size: 20),
              filled: true, fillColor: Colors.white,
              contentPadding: const EdgeInsets.all(0),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ["ZOTE", "NORMAL", "OTHER", "SERVICE"].map((tab) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(tab, style: const TextStyle(fontSize: 11)),
                  selected: _selectedTable == tab,
                  onSelected: (s) {
                    setState(() { _selectedTable = tab; _setStateFilter(); });
                  },
                  selectedColor: textBlack,
                  labelStyle: TextStyle(color: _selectedTable == tab ? Colors.white : textBlack, fontWeight: FontWeight.bold),
                  backgroundColor: Colors.white,
                  elevation: 0,
                  pressElevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              )).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          _dateBtn("From", _startDate, () => _pickDate(true)),
          const SizedBox(width: 8),
          _dateBtn("To", _endDate, () => _pickDate(false)),
          if (_startDate != null)
            IconButton(
              icon: const Icon(Icons.close, color: Colors.red, size: 20),
              onPressed: () {
                setState(() { _startDate = null; _endDate = null; });
                _fetchAllData();
              },
            )
        ],
      ),
    );
  }

  Widget _dateBtn(String label, DateTime? date, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: lightGrey)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 8, color: Colors.grey)),
              Text(date == null ? "Select Date" : DateFormat('dd MMM yyyy').format(date),
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickDate(bool isStart) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() { if (isStart) _startDate = picked; else _endDate = picked; });
      if (_startDate != null && _endDate != null) _fetchAllData();
    }
  }

  Widget _buildMissingWarning() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.orange.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.orange.shade100),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text("$_missingCount items hazina kodi bado.", style: const TextStyle(fontSize: 11))),
          TextButton(
            onPressed: _generateCodesForMissing,
            child: const Text("TAYARISHA", style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 11)),
          )
        ],
      ),
    );
  }

  Widget _buildMainList() {
    if (_filteredItems.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory_2_outlined, size: 50, color: Colors.grey.shade300),
            const SizedBox(height: 10),
            const Text("Hakuna bidhaa hapa.", style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      itemCount: _filteredItems.length,
      itemBuilder: (context, index) {
        final item = _filteredItems[index];
        bool hasCode = item['code'].toString().isNotEmpty;

        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: lightGrey),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            leading: _buildItemLeading(item),
            title: Text(item['name'],
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, overflow: TextOverflow.ellipsis)),
            subtitle: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: lightGrey, borderRadius: BorderRadius.circular(4)),
                  child: Text(item['type'], style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(hasCode ? item['code'] : "NO CODE",
                    style: TextStyle(fontSize: 10, color: hasCode ? Colors.grey : Colors.red))),
              ],
            ),
            trailing: const Icon(Icons.chevron_right, size: 16, color: Colors.grey),
          ),
        );
      },
    );
  }

  Widget _buildItemLeading(Map<String, dynamic> item) {
    if (item['code'].isEmpty) {
      return Container(
        width: 45, height: 45,
        decoration: BoxDecoration(color: Colors.red.shade50, shape: BoxShape.circle),
        child: const Icon(Icons.qr_code_2, color: Colors.red, size: 20),
      );
    }
    return SizedBox(
      width: 45, height: 45,
      child: QrImageView(
        data: item['code'],
        version: QrVersions.auto,
        size: 45.0,
        padding: const EdgeInsets.all(2),
      ),
    );
  }

  Widget _buildFAB() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        FloatingActionButton.small(
          heroTag: "layout",
          backgroundColor: Colors.white,
          onPressed: () => setState(() => _isVerticalLayout = !_isVerticalLayout),
          child: Icon(_isVerticalLayout ? Icons.grid_view_rounded : Icons.view_list_rounded, color: textBlack),
        ),
        const SizedBox(height: 10),
        FloatingActionButton.extended(
          heroTag: "print",
          backgroundColor: textBlack,
          onPressed: _askPrintType,
          label: const Text("PRINT ALL", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          icon: const Icon(Icons.picture_as_pdf, color: Colors.white, size: 18),
        ),
      ],
    );
  }
}